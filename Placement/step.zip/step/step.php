<html>
<head>
	<title>Step</title>
</head>
<body>
	<h1>Step</h1>
	<form method="get">
		<label for="instructions" >Instructions</label><br />
		<textarea name="instructions" rows="20" cols="50">
			<?php echo ltrim($_GET["instructions"]) ?>
		</textarea><br />
		<input type="submit" value="Submit">
	</form>
	<?php
	$instructions = $_GET["instructions"];

	$txtInstructions = fopen("instructions.txt", "w");
	fwrite($txtInstructions, $instructions);
	fclose($txtInstructions);

	$stepper = shell_exec('python stepV8.py RF instructions.txt');
	echo "<img src='image.png' width='100%'></img>"; 
	?>
</body>
</html>
